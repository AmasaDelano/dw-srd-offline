# Thanks

# Influences

If we have seen further it is by standing on the shoulders of giants. Hill
giants and stone giants mostly, but some frost giants and even a fire giant
one time. That got messy.

By this point it’s probably pretty obvious that Vincent Baker’s Apocalypse
World, as well as Gary Gygax and Dave Arneson’s Dungeons and Dragons are the
reason we made this game. The Dungeons and Dragons Basic Set, edited by Tom
Moldvay, and Advanced Dungeons and Dragons were our references of choice.

Our version of Alignment is closely related to Keys from Shadow of Yesterday
by Clinton R. Nixon as seen in John Harper’s Lady Blackbird.

XP on a miss can be seen in a lot of designs—the version seen in Luke Crane’s
Burning Wheel was an inspiration, but this particular take on it comes by way
of John Harper and Paul Riddle’s The Regiment.

Bonds are a perversion of Hx from Apocalypse World with a little bit of the
memories from Freemarket \(by Luke Crane and Jared Sorensen\) thrown in for
spice.

Dungeon World wouldn’t exist without cross-pollination from many other
projects powered by the Apocalypse. Sagas of the Icelanders by Gregor Vuga,
The Regiment by Paul Riddle and John Harper, Monsterhearts by Joe Mcdaldno,
and several unpublished games by Jonathan Walton all were part of our process.

The original idea to mash Apocalypse World and D&D together belongs to our
good friend Tony Dowler. He was gracious enough to let us build on his concept
and carry it through to the shape you see today.

# Tools

Dungeon World was created in InDesign. The main fonts used are Adobe Minion
Pro, Newcomen, and Archemy.

The original text was written entirely in XML to be imported into the book
layout, the character sheet layout, and various other formats. Working in
plaintext allowed us to map to all kinds of different layouts as well as
versioning the files using Git and Github.

We developed Dungeon World a bit like you develop software, so the Github bug
tracker and Dropbox were key tools in making the game a reality.

# Special Thanks

Strasa Acimovic, Marshall Miller, Jason Morningstar, Simon Ward, Greg Cooksey,
Hamish Cameron, Kevin Weiser & the Walking Eye, Steve Segedy, John Harper,
Tony Dowler, Vincent Baker, Gary and Dave \(of course\).

# Contributors

Tresi Arvizo, Jeremy Friesen, Alessandro “Adam” Gianni, Lee Reilly, Nathan
Black, Adam Blinkinsop, Matt Jett, Evan Silberman, Alexander Gude

# Guild Members

Charles Boucher, PK Sullivan, Jeremy Friesen, Sara Williamson, Ara, Rob
Sanderson, John Hawkins, Chris Eng, Rob Brennan, Brian Moroz, Jonathan Abbott,
Tom Scutt, Franciolli Araujo, skullBoy72, Chris Sakkas, Ryan D. Kruse, Jason
Wood, Dylan Boates, Aaron "Tildesee" Friesen, David M. Miles, Felan Parker,
Gianmario Marrelli, Tony Dowler, Tresi Arvizo, Daniel Ornstein, Matt Silver,
Jacob Sulpice, John Mehrholz, Marshall Miller, Matthew Sullivan-Barrett, Max
Saltonstall, Adam K, John Senner, Aaron Rowell, J.B. Mannon, Sean M. Dunstan,
Thomas Ulricht, Sam Carter of Mars, Hans Chung-Otterson, Sanjay Kurichh, Ryan
Macklin, Kuba Koprowski, @ATerribleIdea, Jesse Burneko, Colin Jessup, Bryan
Rennekamp, Tom a.k.a. Warzen, Iserith, Jason Pitre, Steven Jarvis, Jim
Crocker, Hamish Cameron, Max 'Ego' Hervieux, Timothy Adamson, Christopher
Grau, Josh Rensch, John Bogart, Wes Price, Sohum Banerjea, kingston Cassidy,
Alec Fleschner, watergoesred, Matthew Gagan, Cameron Suey, Scott Acker,
Christopher Acker, Jason D. Smith, Justin Wightbred, Jarrod Farquhar-Nicol,
Alan Jackson, Joerg Bours, Joseph "UserClone" Le May, kreg mosier,
Paulo\_Segundo, Anthony Martins, Joe Beason, Stuart McDermid, Vernon "Crypt-
Kicker" Lingley, Matthew Klein, Ben Glickler, Jani Mölsä, Doug Hare, Jeremiah
Frye, Dan Maruschak, Tristan Markert, Jeffrey J. A. Fuller II, Tommy Tanaka,
Phil Garrad, Philip LaRose, Kynnin Scott, Nathan 'Noofy' Roberts, Steve
Segedy, Strahinja "Stras" Acimovic, Jason Grabau

# Backers Bonded to the Book

These brave Kickstarter backers have a bond with Dungeon World, and Dungeon
World has a bond with them:

Simon Ward has seen what no other eyes could see. Matthew Sullivan-Barrett
shot the morning in the back with his Red Wings on. A recent paradox awakened
my nightmares of an anomaly within Jason's soul; I must fix it for the sake of
my sanity. A witch put a spell on Ingo. Aaron is the Gouger of the monstrous
Filibusterer. Aaron still haunts those Crooked Hills. Abrahm wrought the runes
of binding. Adam constructed the eldritch machine. Adam is the bearer of the
Book of Secrets. Adam Rajski keeps the wisdom of the ages safe. Adam rode the
world worm. Adam saved the holy feline. Ahmad and I studied under the same
mentor. Alan is the wearer of the trenchcoat of pretension. Alcionne wears the
crystal talisman. Alec comprehended the multiple meanings of the Zeugmatic
Dialogues. Aleopheus will strike down upon thee with great vengeance and
furious anger those who would attempt to poison and destroy my brothers.
Aleria cannot unsee what she has seen. Alessandro gave me loaded
dice\!Guard—arrest him\! Alexander was once a king; now, naught but an
adventurer. Alitar is the embodiment of Strength. Amy incants the story of the
world. Andi awoke the dormant evil. Andy always plays a bloody wizard. Andy
reverse engineered the rules of the Universe. Annti stranded me in a house of
brigands. Antoine mixed the spell components. Antti is the keeper of the
forgotten lore. Arc keeps safe the sacred sigils. Area 42 is a safe haven for
adventurers. Argent accessed the Aleph. Arvy found a mysterious tome. As
wizards we are bound by birth to protect the realm against all evil. Baern
holds the bridge that his friends might survive. Baf is watched by three
sages. Balmung is the master of the Crimson Sword. Bard enjoys smelling
ancient tomes. Basilios places the celestial crown upon his head. Basteen
covered the ancient tome in fish. Bastinan braved the fires of the Hells. Ben
boondoggles. Ben spoke one of the ten secret words that started the world. Ben
uncorked a bottle of port. Bill kept the dragons well away from the dungeons.
Blake has seen the sacred vision that reveals the impending death of your
master. Bob defended the realm from the horde onslaught. Bob keeps the secret
of the ancient flame wars. Bolthan is the keeper of the white flame. Brad
evaded the demon by hiding in the shadows. Brandan unearthed forgotten
mysteries. Brandon raised the veil of darkness. Brent harnessed the power of
lightning. Brett is the keeper of Secrets. Brett Zeiler is extrenely arrogant,
but is the best at what he does. Brian controls the chaos of creation. Brian
founded a city out of chaos. brian has seen the fnords. Brian helped batter
down the door to the armory. Brian is bonded to the bonder of bonds. Brian is
searching for his father's lost sword. Brian is the inheritor of forbidden
lore. Brian is too trusting. Brian slayed the sleeping sloth. Brindy embraced
the night as the stars aligned. Brought knowledge to the masses. C & K are
together at the End. Cabuster procured the Papers of Possibility. Cade hurled
the flask. Cameron tells the old tales around the campfire. Capellan cares not
for your paltry friendship. Carl is the heir of an ominous legacy. Carmin is
the bearer of the cloak of shadows. Casey is a disciple of the Red Star.
Casidhe hoards any knowledge she discovers. Chamelaeon has discerned the
pattern of the stars. Chiang-Chen has an ancestral blade-demon in his palm.
Chiv is aeon dead and wields unearthly power. Chris begat many adventuring
heroes. Chris consults his library. Chris discovered the first seal. Chris
Dulsky summoned an unspeakable thing. Chris is the ruler of Pillow Mountain.
Chris killed the crazed cockatrice. Chris knew the lumber consortium was
behind the alien landing cover-up. Chris knows secrets even the vizier is
unaware of. Chris takes +1 forward in any game run by Adam Koebel. Christian
is the bearer of the eternal light. Christian Lindke discovered a magical new
world. Chroma owes nothing to Dark Jessop. Clark discovered the lost text
\(and Amanda corrected it\). Clifford keeps the Arcane Knowledge. Clinton will
play an important role in the events to come. Clyde is the keeper of the
spoken word. Colin is powered by the apocalypse dragon. Connaught strove to
preserve the ancient code. Connor is the cookie whisperer. Conrad saved my
family from poverty. Corinthi brought low carb snacks. Cork is a master of
elemental magic. Cravatosaur is the befouler of the sacred pool. Curt finds
all the monsters that burst out of the ground. Damien's blade is not magical
though his skill makes it seem that way. Dan binds the sacred tome. Dan knows
the monkeys will be his undoing. Daniel discovered the freedom of simplicity.
Daniel uncovered the clockwork of the Cosmos. Danohead is a puddingmancer
nonpareil. Darkfeather unearths the lost treasure of. Dave has unmasked the
Key Master. Dave Insel the Bringer of Ultimate Awesome. Dave on honey-dew has
fed, And drunk the milk of Paradise. Dave struggled through the 7 Hells to
earn this book. David has gained the affections of your betrothed They may not
realize it, but you know this to be true. David is burdened by the Holy Word.
David is cool with whatever we say. David knew the doppelgangers secret. David
paid the price with dark magics. David revealed the truth - to everyone but
himself. David stole the secret that sealed the stair. Dean vanquished the
Great Evil of T'lorin. Deimen has some strange significance to my god Any
miracle I beseech in his name comes out reversed. Derek emerged from the ruins
carrying an ancient tome of eldritch lore. Derek released the demon within.
Derek speaks the Unspeakable Words. Dithmer is the guardian of the forbidden
tome. Dom has travelled under far stars of the future. Douglas Justice is King
of the Dwarves. Dovre the heir the the mountainking, keeper of the ancient
hall. Doyce found long-lost secrets in a forgotten library. Drake broke the
first seal. Dreamstreamer camped the Final Confrontation and put an arrow in
the Barbarian's knee. Drew is bound to no-one. Drew looted his War-Chest for
this book. Drewid spoke the arcane spell from from the ancient tome.
Drnuncheon knifed many people between the ribs. Duane has slighted me with his
Terrible Idea. Due to a magical accident she is your sister-clone. Dufresne
uncovered the means to open a portal to an unholy dimension. Duke Monte hung
out with the Goblins. Dungeon World taught Boabdil the power of Awesomancy.
Dustin found them in the darkness. Dwarven Chris kept dying over and over.
Dylan knows the song to summon the spirit wolf by heart. Dylan plays with some
seriously scary lizard men. Dylan summoned forth that which can not be named.
Edomaur is the maker of the wood swords of the green magic. Edouard fears
Thulsa's rage, it will one day turn on us. Einroy defended the wall. Elkan
casts good ol' Magic Missile. Elric wove the web. Eric sacrificed an eye to
peer into the future. Erik is running low on hearts. Erik reps Thri-Kreen
life. Ernesto made the Barbarian happen. Experience points be damned John will
not slay another farmer\! Falcros wields the sphere of power. Fax shifted the
walls of the dungeon. Fel stole the cursed book. Felan wields a stalagmite as
an improvised weapon. Felix has sealed away the cursed axe. Fiddy is the
master of many worlds. Finnian stole three pages from the book of rituals.
Flavio is the bearer of the hat of grumpyness. For Gavin, the Truth is more
holy than the Book. Fox kept the nexus of portal conduits concealed. Francis
vainquished the darkness with but a smile. Fred has uncovered the true nature
of reality. Fred was lost to reason when he donned the Evil Hat. Gabriel knows
the names of all the stars in the sky. Gant and Roland have faced the trials
of world, and they have touched Paradise. Garry awakened ancient magics. Gary
Hoggatt may be a descendant of Erdrick. George answered the call of the Final
Trump. Ghost Bear is haunted by the spirits of those he have defeated.
Gilmaldor Half-Eleven is the silent assassin lurking in the shadows. Gina cast
the spell of eternal marshmallows. Gip has the strength to act. Glenn explored
the lost catacombs. Godfrey is a paragon of goodness and wisdom; when in
doubt, I defer to their judgement. Gondry mocked my beliefs. Grandmaster
Jarrod asks, “When type of monster is it?”. Greenie spoke the Unutterable
Name, dooming us all. Greg discovered the mystifying elixir. Gregor Hutton had
foreseen it. Grimwald is trying to unlock the secrets of the scroll of winds.
Hamish is the blood-stained sword of the Black Elf nation. Hans holds the key
to weaving spells of Uncertainty. Hawk has the largest pile of fail XP. Henry
dreamed of places strange. Herman always gets the flaming sword. Hilary is
thinking what you are thinking. I am Dan's long lost sibling. Ianovos restored
the link to the ancestral eight. Ios heard the call of the Wild Hunt, and
never returned. Irene will make the last stand. Irina was taught to make
secret potions by the old woman. Isabelle and Emma have shown me the way, now
I hope to return the favour. Isen is the defender of the Silverhand. J escaped
the hook that hungers. Jack inexplicably can understand the language of
Dragons. Jack squandered his only Wish on a good deed. Jake has a jinx on him.
James explored all of the wizardly tangents. James held no love but for money,
and trusted no-one but his blade. James is the tester of many tablets. Jamie
waits in the shadows. Jarod founded the Musty Dragon Inn franchise. Jason
drank from the well of common sense. Jason looted the temple of the Ancient
Ones. Jason rides the Glyphon. Jay is the wielder of the magical boot of horse
theft. JB was buried with the Opal of Xul-Gar. Jeff turned down his right to
the crown of the goblin kingdom. Jeffrey struggled not against flesh and
blood, but against the rulers, against the authorities, against the powers of
this dark world and against the spiritual forces of evil in outer realms.
Jeffy poked a toothpick through the membrane. Jeremiah was taken by horrors of
the deep Never to be seen again. Jeremy is always one book away from a
complete set. Jeremy slew a red dragon, costing him a limb. Jeremy's mind
spent lifetimes wandering the spirit realms, in a deep lotus-trance. Jerome
stitched the bindings of the ancient tome. Jess opened a Doorway not fit for
mortal souls. Jim climbed the Infinite Tower. Jingo uses the stone, one last
time. Joe the mythical waffle taunter. Joe's campaign fronts read like the
script from a telenovela. Joel shattered the Ancients' ignorance. Joerg is the
guardian and wielder of the first sword. Johann warder of the wyrd. John cares
deeply for someone, but they are kept apart. John is the keeper of the sacred
kennel. John must cleanse his gear daily of evil spirits. John once forged a
celestial breastplate. John sundered the Faithless Gate. Johnstone doesn't
like anything. Jon doesn't see the point. Jon McCarty and I had a violent
falling out. Jonathan brandishes the vorpal great axe. Joseph “UserClone” Le
May NEEDS FOOD BADLY\! Joseph has awakened what lurks in the deep. Josh Flint
stole pages from the leaves of the world tree. Josh is bearer of troubling
truth. Josh spoke the unspeakable tale. Josh was there in the Dawn Times.
Joshua enscribed the mark of the ereboi huntsman. Joshua is the ally of the
animals of the forest. Joshuha forged the perfect weapon. João is the master
of the large sack. JP Sauers traversed the outer planes. Julien Pirou is in
the secret world behind the GM's screen. Justin hid something beautiful in a
terrible, deep dungeon. Justin Wightbred lead the charge against unnecessary
escalation. Jürgen Mayer is the shadow that kills you in the night. Kairam is
the immortal sage of the swamps. Karuk broke the glittering crown. Kate sees
barmaids. Keith drew on the forbidden power that dwells below. Keith is the
undiscovered scion of the hidden realm. Keith the Keeper of Arcane Lore. Keith
will explore Dungeon World with any who are willing to Adventure\! Kem teaches
that the only true weapon is the mind. Ken is the servant of the Secret
Spring. Kenny unlock the ancient gate. Kestral still walks Insanity's Edge.
Kevin is a disciple of His Weirdness: Al Yankovic. Kevin is entrusted with
secret, ancient knowledge. Kevin is the arcane master of the ambulatory eye.
Kingston leads old friends into battle with Teuthus, the God who crawls
beneath the waves. Kirby drank from the Ewer of Memories. Kreg carried the
Swagger Stick everywhere he went. Kristopher despises most people, but keeps
it to himself if he thinks you might by useful Savage invective befalls those
that have no use. Kurt tumbled through the demon door. Kyle owes fealty to the
Queen of Winter. Kyree rules the ruins with fortune and fate. Larry the
unprintable. Laura has special luck. Lazaar is the master of whispers. Leo
Lalande opened the astral rift between worlds. Leslie grinds on towards the
coming dawn. Lidrick Barrisbren strung his Lute of Lightning. Liri rejected
the fulfilling of her deepest wish by the goddess. Logan lost the phylactery.
Lucias got tangeled in wizard sleeves. Lucien is the light that binds and
demands. Luis crossed oceans of time. Lukas fought at the Gates of Oblivion.
Luke cannot use the force. Luke has quenched the fire of creation. LXD lives
on\! Lythias sought the secrets of the Serpents' Labyrinth. Mabon breathes in
the wonder of the night sky. Magic brought down the gate. Makr stole a tear
from the Eye of the World. Malabreiga's sinuous body lies wreathed in purple
flame. Malo delved down and down again, deep into the world. Manilla has given
me enlightenment that I can never repay. Marc has kept the Old Ways secret all
his years. Marco is the Keeper of Truth. Margaret delves tomes for knowledge.
Marielle never learned how to read and has been faking it this whole time.
Mark awoke the gods. Mark bears the brands of the seven holy silences. Mark
cooked breakfast at the gates of darkness. Mark has sung the halfling song.
Mark immanentized the eschaton. Markku knows where the Arkenstone is located.
Markus has seduced the incubus of the seven cauldrons. Marshall married my
sister when no one else would. Martin unearthed the antediluvian arcana. Mary
knows what we say to Death. Matt delivered the chalice to the village elders.
Matt discovered a wonderful forest for His family. Matt followed the echoes of
eternity. Matt was bemused by Gnomish poetry. Matthew 'Jarikith' Monagon
rolled the Polyhedrons of Chaos. Matthew is the chosen vessel of the Spirit of
Wisdom. Matthew shot morning in the back with his Red Wings on. Matthias took
up the nearest tome and thumbed it through. Mattie promised to teach me the
weaknesses of the human mind. Meg is the keeper of all my stories. Melody
keeps the forbidden secrets. Mendez stole the Wudang Manual Again. Micah is
the bane of the demon lord, slayer of the spider priest, spiller of the silver
blood. Michael dreams of worlds inside everyday objects. Michael knows the
ancient rhyme. Michael read the starry wisdom between the words. Michael will
sacrifice everything and everyone to achieve his goal. Mike faced the dragon-
bears. Milo thinks the section you need to read is around page 56. Mitchifer
is the chosen of the God of Death. Mo is the holder of the flame. Murgh Bpurn
does it virtually all the time. Nathan is the inheritor of a great and
mysterious power. Neal found the darkness within. Nemo detected slanting
passages. Nex hides in the shadows. Nicholas consumed the mythical biter
brewery's blinding beer. Nicholas' ‚Äúplan B‚Äù is kill it with fire,
acceptible at any time. Nick is heir to both warring kingdoms. Nick is the
guardian of the forbidden knowledge. Nick is the keeper of the ancient tome.
Nikolai is the keeper of the Talisman of the Ranging Pack. NinjaDebugger
liberated this book from the Library of the Ages. Noam is still residing at
the bottom of that pit trap. Noofy has adventured all over the world to be re-
united with his True Love. Nora feeds the trolls. Okerstroker broods in the
corner with a watchful eye. Oliver is the master of a thousand spells. Oliver
turned out to be good-natured, generous and likeable; in three days no one
could stand him. Oliver was menaced by a giant owl. Oscar is the Secret Fire.
Oscart knows, To Keep The Peace, Prepare For War. Owen attacked the darkness.
Owen is the ringmaster of the workers of dark creation. Pat presided over the
sacred smoke ceremony celebrating peace between the tribes-men of plains .
Paul and I have shared dreams sent to us from subaquatic temples of cyclopean
stone. Pego was there when ‚ÄúPosta\!Pizza\!Pacco\!Äù was uttered. Percy
unveiled the secret of the Hoss. Peter knows that The Path to Wisdom lies down
the Eternal Road. Petrus is nearly proficient with the double-club. Phil is
the speaker of dreamtruth. Philip opened the archives and discovered a World
of Dungeons. Philippe Debar was blessed once and then thrice. Quinn unlocked
the ancient armory. Raf is the source of cosmic grumpiness. Ragnar taught me
how to cook on the road. Rainswept's sorrow is here with him. Rausdour hates
bats. Ray is master of the dungeon and slave to the dice. Redhan banished an
ancient evil. Ren√© deciphered the riddle of the thousand deaths. Rhovanor has
a shard of the cup of Eternal Life implanted in his chest. Richard found inner
harmony. Richard writes with the sacred ink of the ancients. Richard, Speaker
to the Modrons. Rick bears an ominous mark in the superstitions of my people.
Rick forgot the most important lesson. Rishi “mistakenly” ate an owlbear
pellet. Rob holds the keys to the locks. Rob is lost in a forbidden tome of
arcane knowledge. Rob is the chosen protector of the sacred ale. Rob Justice
sleeps in the pines. Rob kicked down the door in the name of the King. Rob
shot the food. Rob united the Bee Kingdoms. Rob wields the hand, as he
journey's forth with the SOG & SAUF. Robert Bruce told you exactly what you
wanted to hear. Robert helped me in a time of need. Rocha published Dungeon
World in Brazil\! Rodrigo is the teller of tales. Roman is the Keeper of the
Temple Ruins. Ross was trusted with keeping the ancient tome. Rune is the
wielder of the warhammer of grim irritation. Russell is the bearer of the
sacred twenty sider. Rusty looked into the Mind of Darkness. Ryan is He Who
Stalks Beyond the Walls. Ryan is the Master of the Dungeon. Ryan spoke the
word. Ryan Webster is the prince who married his princess. Sage opened his
brain to the Worm God first, mmm, dirt. Sally is a friend of the white cat.
Sam is the Seeker of Knowledge. Sam wielded the Flame of Creation. Samuel
stood with them at the end. Savannah possesses a true strength that cannot be
overcome. Sayler is a hoopy frood He deserves a new character class:
Spelljammer Buccaneer\! Scathaigh is the eternal Herald of the Starshadow.
Scott Belchak bears the thanks of the creators. Scott delved deep into the
Book and came out changed. Scott was taken unawares. Sean Dunstan spread word
of the wonders of the dungeon to the darkest corners of the world. Sean is
heart-bound to Shawna Lee through the Rite of Stone Wood. Sean punched a
dungeon right in the face. Sean secretly transcribes the hieroglyphs of the
RJS Empire. Sean unrolled the freshly minted scroll. Sean was here\! Shane
Knysh is the last royal cartographer of the united southern realms. Shane
seeks what the ancients knew, but chose to hide. Shannon opened the book of
the forbidden. Shawn was jailed for a crime that I committed. Silj is
completely insane\! Simba left his mark on the town, leaving it under his
protection. Simon carried the torch for no man. Skender dicovered the
tarnished Glinn circlet. Slay-Tor used the Hardcover to shatter the spines of
lesser books. Someone will choose poorly and be killed, unless I intervene.
Sophie uses this tome to bend realities. Sovern trusts in the creators. Stacey
raised the standard of Friendship high upon the battlefield. StacyRex
possesses the Eternal Bag of Happiness. Stefan is the keeper of knowledge.
Stella Christina Hall woke up in the middle of each night to learn more from
this book. Stephen is the keeper of the book of secrets\! Steve has emerged
victorious\! Steve is sworn in life and death to his son Connor. Steve sang
throughout the night. Steve wants to know who you truly love. Steven has
opened the secret eye of Angra Mainyu. Stew lead the charge against the horned
dragon. Stewart saw into the spaces between the spaces. Stras is the one that
keeps carving faces on all the trees in the Godswood. Tara fought the gazebo.
Tewhill broke the bugbear's will. The bigger they are, the harder Michele
hits. The Book has filled my mind with erudition. The Crimson Dragon falls to
my demon blade. The Demonlords await the Convergence. The host speaks for the
gophers. The Legions of Gremlins unearthed the deathly tomb. The Lord's Secret
mistress is Adrian. The only boundaries that exist are those of the mind. The
pale cur sleeps on the book, either growling or snoring. The party shivered at
the sinister sound. The prophetess Seldanha remains ever watchful of the
vizier's machinations. The Rogue learned his trade from the ancient Assassin's
Guild. Thom braved the sideways tower. Thomas decieved the others. Thoradin
saved the vale from the mighty orc king. Thorgrim bears the Book of Grudges.
Thunder is Newt's brother, he rides the winds of destiny\! Tim found his
courage in the length of long halls and the depth of blue eyes. Tim unearthed
the true history. Tleroth stood and held the breach. Together, Cazantyl and I
escaped from a cult. Tom upheld our ancient honors. Tomar can see to the heart
of anything. Tony survived the demi-lich. toridas unleashes the power within.
Tran knows where the shoggoth lies dormant. Travis really should have known
better Really. Tresi completed a perilous journey to the smoldering mountains.
Tristan invoked the forbidden voice. Tucker is the most worthy of all of
Carles' disciples. Tulip knows where the Bees are. Typhur stood fast, despite
the cost. Tyson reps Thri-Kreen life. Ulai stands vigilant at the gate.
Ungerford's brain aches with the want of knowing. Valtiel is in league with
the Fair Folk. Veng has gained mastery of the ancient secrets. Vicki is a
wannabe \(though hopefully not forever\) Renaissance woman :\). Vidal is the
Paladin of the Great North. Vincent walks under the scrying sun. Vivian stole
the Knight's heart. Voodoo marveled at the discovery of the World. Warren
wondered what bond words to write. Warzen has a new cat familiar. Wesley
expressed disinterest in writing this. Wesley was the guardian of the blind.
Whitney awakened the forgotten gods. Will knows the Spectre's secret name.
Will was initiated into the conspiracy of the Duke's court. William knows the
secret that will undo everything. Willow is the conqueror of fallen gods. With
words a piece of Brian's spirit will live on in this tome. WolfSamurai forever
sealed away ancient evils from the world. Wordman wears the silver mask.
Xthulu rose from a watery grave. Yet again following Wightbred into strange
dungeons. Yrkoon wields the soul-drinking sword. Zachary learned an ancient
song, but fears the day when he will be called upon to sing it. Zed journeyed
to the frigid north to meet Jex. Zed of Sosaria stepped through the gate eager
to explore. Zhang Fei has a history of causing strife among his subordinates I
would do best to keep my distance from him. Zirk came to chew bubblegum and
play games, and he's all out of bubblegum.

# Kickstarter Backers

“Blue Hair Bob” Puckett, “Evil” Avi Zacherman, >B, a-bomb & g-girl, A.
Herbert, A. Nonny Moss, A.J. LoPresti, Aaro Viertiö, Aaron “tildesee” Friesen,
Aaron Greenspan, Aaron Hamric, Aaron Malone, Aaron Olson, Aaron Potts, Aaron
Rowell, Aaron Tudyk, Accidental Fraser, Ackinty Strappa, Adam “Woulf” Fink,
Adam Canning, Adam Chute, Adam Coleman, Adam Dray, Adam Flynn, Adam Fox, Adam
Hegemier, Adam J. Piskel, Adam Juden, Adam K, Adam Minnie, Adam Robichuad,
Adam Waggenspack, Adam Waite, Adam Wheelock Boisvert, Adam-Ross, AdamD VA,
Addy, Adreanna, Adrian Brooks, Adrian Burton, Adrian J George III, Adrian
Magaña, Adrian Price, Adrian Sotomayor, Adrienne Mueller, Al Billings, Alan
Barclay, Alan Clark, Alan De Smet, Alan Millard, Alan-Michael Havens, Alastair
Bishop, Albert Andersen, Alden and Katherine Strock, Alejandro Fernández
Ortega, Alex, Alex “Ansob” Norris, Alex Baldwin, Alex Bergquist, Alex C.
Trépanier, Alex Davies, Alex Dingle, Alex Fradera, Alex Gwilt-cox, Alex
Hakobian, Alex Higdon, Alex Hunter, Alex Mosher, Alex Nuzzi, Alex Watters,
Alexander “Elric” Zorin, Alexander Alabaster Hernandez, Alexander Cumming,
Alexander Kell, Alexander Keurvorst, Alexander Lucard, Alexander Siegelin,
Alexander Wasberg, Alexandra Hebda, Alexandre Denault, Alfred Rudzki, Alison
J. Dodd, Alistair Lamb, Alphonso Butt, Alva Hopkins, Amado Glick, amel, Amy
Minucie, Anders Bohlin, Anders Edqvist, Anders Scholl, Andre Kajita, Andrea
Ungaro \(Ander\), Andrei Mouravski, AndrethSaelind, Andrew, Andrew and Heleen
Durston, Andrew Asplund, Andrew B. Chason, Andrew Blake, Andrew Byers, Andrew
Carbonetto, Andrew Collins, Andrew Croftcheck, Andrew Ducker, Andrew Gatlin,
Andrew Gill, Andrew Kenrick, Andrew Knippling, Andrew Linstrom, Andrew
Maizels, Andrew Medeiros, Andrew Menear, Andrew Morton, Andrew Muttersbach,
Andrew Saunders, Andrew Schubert, Andrew Watson, Andrew Wooldridge, André
Bogaz e Souza, Andrés Acevedo, Andy 'awmyhr' MyHR, Andy Bates, Andy Blanchard,
Andy Deckowitz, Andy Goldman, Andy Hsu, Andy Kitzke, Andy Prime, Andy Smith,
Anna Kruse, Anonymouse, Anthony Bucchioni, Anthony Hersey, Anthony Martins,
Anthony Popowski, Anthony Spulnik, Anton Olsen, Antonio Merùmeni, Antonio
Messaggiero, Aníbal J. Delgado, Ara, Aria H.Y. Cheng, Ariele Agostini, Arno
Ludo, Arog, Aronhiawakhon, Asher Dale, Ashley Clifton, Ashley Raines, Atlatl
Jones, Atomixwah, Aurelia Wyler, Austin Conley, Austin Stanley, Azato, Azhrei
Vep, badsmoothie, Balazs Oroszlany, Balthus Borazar, Barac Wiley, Barry Baker,
Barry C. Cook, Basil Lisk, Batman, Bay Chang, Bay Grabowski, Beau McCarrell,
Bechamolle, Ben Archer, Ben Erdin, Ben Hale, Ben Hartzell, Ben Johnson, Ben
Leftwich, Ben Mabbott, Ben Mandall, Ben Murphy, Ben Neilsen, Ben P. Balestra,
Ben Vincent, Ben Wakeland, Ben Wlodarczak, Ben Wray, Benjamin “Bailywolf”
Baugh, Benjamin Bement, Benjamin Herr, Benjamin Hinnum, Benjamin James Meck,
Bennett Smith, Bernard Gunkleman, Bert Isla, Bill \(Gryffen88\) Stilson, Bill
Brickman, Bill Charleroy, Bill Kokal, Bill Parrott, Bill Valera, Billy
Compton, Björn Söderström, blackcoat, Blake Hutchins, blanksuspect, Blkct, Bo
Williams, Boaz Bibi, Bob Hanks, Bob Huss, Bob Muir, Bob Poteete, Bobby
Jennings, Boon Sheridan, Boris Belitsky, bowmore, Brad, Brad Morris, Brad
Osborne, Brad Wilke, Bradford Yurkiw, braincraft, Brandon “Jabby” Jeffries,
Brandon Jordan, Brandon Landry, Brandon Perkins, Brandon Schmelz, Brant
Clabaugh, Brawley Avalon, Brendan Adkins, Brendan G Conway, Brendan Hutt,
Brendan Lew, Brendan Power, Brennan Haase, Brennan O'Brien, Brennan Taylor,
Brennen Reece, Brent Sturdevant, Bret Gillan, Brett Myers, Brian “Arkayanon”
Holder, Brian “BP” Paul, Brian “Vomax” Smith, Brian A Liberge, Brian Awis,
Brian Cooksey, Brian E. Hollenbeck, Brian Engard, Brian Gerken, Brian Leet,
Brian M McCarthy, Brian McCord, Brian Minter, Brian Sniffen, Brian Spicer,
Brittany Wong, Brooklyn Indie Games, Bruce Curd, Bryan, Bryan Meadows, Bryan
P. Chavez, Bryant Durrell, Bryant Paul Johnson, Bryce Bolliger, bsx, C.
Edwards, C. W. Marshall, Cactusse, Caleb Osborn, Caleb Van Bloem, Cam Banks,
Caoimhe Ora Snow, Carey Williams, Carl, Carl Klutzke, Carl Rigney, Carl Witty,
Carolyn and Nick Atkins, Carson Hill, casey forsberg, Casey McKenzie, Casey
Walton, Cat Peters, Catherine Hardin, Cerity Tradewind, Chad, Chad “T-Rex”
Laws, Chad Bowers, Chad J. Bowser, Chad Jemmett, Chad Reiss, Charles, Charles
Alvis, Charles Long, Charles Starr, Charlie, Charlie Reece, Cheryl Trooskin-
Zoller, Children of the Lost Eden, Chloe Katzburg, Chris A Challacombe, Chris
Adams, Chris Bennett, Chris Brooks, Chris Brua, Chris Clary, Chris Clouser,
Chris Czerniak, Chris Darden, Chris DeCarolis, Chris Fee, Chris Fowler, Chris
Gardiner, Chris Heinzmann, Chris Hopkinson, Chris Kirby, Chris Laine, Chris
Lazenbatt, Chris Longhurst, Chris Murray, Chris ONeill, Chris Parker, Chris
Pullen, Chris Rogers, Chris S, Chris Shablak, Chris Shields, Chris Slazinski,
Chris Sloan, Chris Sniezak, Chris Whetstone, Chris Wiegand, Chris Woods, Chris
Yates, Christian Abratte, Christian Griffen, Christian Leichsenring, Christian
Leonhard, christian theriault, Christof, Christoph Boeckle, Christoph Weber,
Christopher Grau, Christopher Haba, Christopher Haze, Christopher Lee,
Christopher Maikisch, Christopher MZ Sauro, Christopher Ogden, Christopher
Severs, Christopher Smith, Christopher Smith Adair, Christopher Urinko,
Christopher W Mercer, Christopher Weeks, Christopher Welch, Chuck Cooley,
Civil Savage, Clint Morris, Cody “Pax” Markle, Colin and Ian Pinkerton, Colin
Booth, Colin Cherry, Colin Freeman, Colin M, Colin Roald, Connor Alexander,
Cookie Saxton-Ruiz, Corra, Count Kirith Urah Kazar, craig guarisco, Craig
Hatler, Craig Janssen, Craig McRoberts, Craig Perko, Creature Entertainment,
Cree & Richard Boyechko, Creidieki Crouch, Curran Carmichael, Curt Meyer, Curt
Steindler, Curt Thompson, Cy Myers, D. Weaver, Dag Sverre Syrdal, Dale
Horstman, Dallas McNally, Damien Holder, Damien Laing, Damien Park, Dan
Bruguier, Dan Cruickshank, Dan Grabowski, Dan Hall, Dan Luxenberg, Dan
Marchant, Dan Maruschak, Dan McSorley, Dan R., Dan Rosenthal - Game Law
Partners, Dan Shaurette, Dana B, Daniel Brannick, Daniel Brown, Daniel Corn,
Daniel Drew, Daniel G. Dyrda, Daniel H. Levine, Daniel H. Spain, Daniel
Hartnett, Daniel Hoffmann, Daniel J T Moore, Daniel J. Owsen, Daniel M. Perez,
Daniel McKenna, Daniel Morey, Daniel O'Connell, Daniel P. Shaefer, Daniel
Roanoke, Daniel Sacdpraseuth, Daniel Steadman, Daniel Westheide, Daniel, Max &
Mason, Daniele Di Rubbo, Daniele Ruggeri, Danny, Darcy, Darcy Burgess, Darin
Shepit, DarkMoonINC, Darrel, Darren Brewster, Darren Watts, Darth Butternutz,
Daryl Gubler, Dave “The Game” Chalker, Dave Bapst, Dave Campbell, Dave Kester,
Dave Rezak, Dave Ruppel, Dave Skogstad, Dave Tarr, Dave Younce, David, David
'Doc Blue' Wendt, David A. K. Lichtenstein, David A. Nixon Jr., David B, David
B Silverman, David Bolick, David Ellison, David Gallo, David Gilbert, David
Hertz, David Hines, David Kazibut, David Lai, David M., David M. Miles, David
Macauley, David Moore, David Morrison, David Murray, David P, David Ross,
David Schmitt, David Steiger, David Stoneking, David Thackaberry, David Thiel,
David V Zarubin, David Wetterbro, David Z Chen, Dean Gilbert, Dean Langford,
Dean McNabb, Declan Feeney, Deirdre Calvaneso, Demian M Walendorff, Denis
Azuaje, Dennis Kadera, Denys Mordred, Derek Cardwell, Derek Handley, Derek
Lettman, Derick Larson, desert steampunks, DeShawn Luu, Detective Clayton, Dev
Purkayastha, Devin C, Devon Campbell, Dexter Mcdot, Dick Page, Diogo Nogueira,
diversionArchitect \(David C. Amarasinghe\), Dominic Claveau, Don Barnett, Don
Gardner, Don Schlaich, Donald Tyo, Doug Blakeslee, Doug Bonar, Doug Daulton,
Doug Hagler, Doug Pirko, Doug Smidebush, Dougal Scott, Douglas S. Keester, Dr
Ivo Robotnik, Drew Hart-Shea, Druaightagh, Dryn, Duane Moore, Duncan Burridge,
Duncan Pickard, Dustin Gulledge, Dylan Green, Ed, Ed Casilio, Ed Kowalczewski,
Ed Thater, edchuk, Eddie Clark, Eddie Goehner, Eddy Webb, Edgar Gillock,
Eduardo H Schaeffer, Edward Damon, Edward Hand, Edward McWalters, Einar
Wolfsauge, el Mīko, Eldergamer, Eli Barnes, Eli Baskir, Elias Mulhall, Ellen
Zemlin, elmitxel, Emanuele Mandola, Emery Shier, Eoin Burke, Eon Fontes-May,
Eric Coates, Eric Duncan, Eric Haddock, Eric Heisserer, Eric J. Boyd, Eric
Lytle, Eric Paquette, Eric Stevens, Eric Stewart, Erich McNaughton, Erick
Slazinski, Erik Schmidt, Erik Tenkar, Erika Aho, Erin M. Conder, Eskimo Ace,
Euan, Eusebi Vazquez, Evan Franke, Evan Parker, Evan Silberman, Evan Torner,
Everitt Long, evil bibu, Ewen Cluney, Ezio “Aetius” Melega, Ezra Bradford, Fay
Onyx, Felix Tristram, Fenway5, Fercthu Albor, Ferïn, Filth Monkey, Fitz
\(GameKnightReviews.com\), Flo Hoheneder, Florian Hübner, Foreezbus,
Franciolli Araújo, Francis Dickinson, Francisco Castillo Segura, Francois
Gnosis, Frank “Peach” Piechorowski, Frank B., Frank Blazkiewicz, Frank Fiol,
Frank Jarome, Franklin Kenneth Hyatt, Frans Evaldsson, Franz Daubner, Fredrik
Hansson, Fredrik Sivertsson, Fridrik Bjarnason, G. Hartman, G.U.B.A.R.
Podcast, Gabriel Johnson, Gamethyme, Garabaldi Montrosse, Gareth DeWalt, Garou
Verroq, Garrett Kelly, Garth Dighton, Garth Elliott, Gary Arkham, Gary Beason,
Gary Bradley, Gary Kacmarcik, Gaston Phillips, Gaunt, Gauthier Descamps, Gavin
Cermak, gaz moore, Geekfromtheperilousrealm.com, Gentan Schulteis, Geo Pine,
Geoff Bowers, Geoff Dash, Geoff Mochau, Geoffrey William Kennedy, George
Shanahan had no bond, Gerald, Gerolf Nikolay, Gerry Saracco, Geza Letso,
Giacomo “jackvice” Vicenzi, Gianluis Ramos, Gilbert Podell-Blume, Giulia
Barbano, Giuseppe D'Aristotile Jr., Glenn R Buettner, God, Gokce Ozan Toptas,
Gornul, Gozuja, Grandy Peace, Grant Chen, Grant Greene, Grant Lindsay, Grat
McGrat, Grayson Davis, Greg Basich, Greg Fulford, Gregor Vuga, Gregory Heim,
Gregory Parsons, Gregory Simkins, Grey Growl, Grimwade, Grinpis, GS Lamb,
Guenther Kronenberg, Guillaume “Nocker”, Guns\_n\_Droids, Guy Bowring, Guy
MacDonnell, Guy Sodin, H Shurmer, H. M. 'Dain' Lybarger, Hal “Venjack” Neat,
Hamish Cameron, Hans Erich Biorklund, Harold Balsac, hellium, Henning Wollny,
Henri J. Bauer, Henrik Jernstedt, Henrique Rodrigues, Henry, Henry Vogel,
Henry White, Henry Wong, Hiroki Shimizu, Hisashi, Hjortkayre, Holger
Niederschulte, Hualex, Hugh O'Connor, Hugh Pearse, Hunter W., I. Calderon,
Iain McAllister, Iain Milligan, Ian Andersen, Ian Charland, Ian Mothorp, Ian
Raymond, Ian Rose, Ian Toltz, Ian Torwick, Ian V. Caldas, Ignacio Rodríguez
Chaves, Ingrid Cheung, Irven “Myrkwell” Keppen, Isaac Ahuvia, Isaac Carr,
Isaac Karth, Isaac Williams, Ishai Barnoy, Itchetiky Jutmundus, Ivan Vaghi, J
Aaron Farr, J Scag, J. Derrick Kapchinsky, J. Myllyluoma, J. Todd Scott, J.C.
Lundberg, J.O. “Volsung” Ferrer, Jack Burnett, Jack Gibbard, Jack Gulick, Jack
Hay, Jack Kenyon, Jack Miskelly, Jack Norris, Jack Waitkus, Jackson Allen,
Jacob D. Adamo, Jacob M. Moore, Jacob Maas, Jacob Marks, Jacob Sulpice, Jaime,
Jaime, Jake Cyriax, Jake E. Fitch, Jake Parks, Jalister, James “Cornelius”
Patterson, James A. English, James Brown, James Buckingham, James Campbell,
James Chilcott, James Davies, James Dillane, James E. Winfield Jr, James
Flinders, James Gabrielsen, James Jandebeur, James Jeffers, James John, James
M. Spahn, James Newman, James Oswald, James Ritter, James Roberts, James
Stuart, James Tadashi Graham, James Yasha Cunningham, Jamie, Jamie Furtner,
Jamison T Thing, Jams Mastodon, Jan Egil “Jedidiah Curzon” Bjune, Jan
Schwindowski, Jan-Yves Ruzicka, Jani Waara, Janna, Janne H. Korhonen, Jared
Hunt, Jaron Kennel, Jarrah James, Jason, Jason, Jason, Jason “Ludanto” Smith,
Jason “Zebulon” Greenwood, Jason & Kassie Hanks, Jason & Kat Romero, Jason
Buchanan, Jason Childs, Jason Dettman, Jason Flowers, Jason Grabau, Jason
Hilberdink, Jason King, Jason Kottler, Jason Leinen, Jason Morningstar & Steve
Segedy, Jason Pasch, Jason Paul McCartan, Jason Valletta, Jay Shaffstall, Jay
Steven Uy Anyong, Jays Mackie, JC Spencer, Jean-François Héon, Jeff, Jeff
Bowes, Jeff Healy, Jeff Prather, Jeff Raglin, Jeff Troutman, Jeff
Vansteenkiste, Jeff Wowkowych, Jeffrey Collyer, Jenni Higginbotham, Jens
Alfke, Jered Heeschen, Jeremiah Lee - @Trifecta\_Games, Jeremiah McNichols,
Jeremy Cerise, Jeremy D. Smith \(zaydoc\), Jeremy Kostiew, Jeremy Puckett,
Jeremy the Green Slime, Jeremy Whalen, Jeremy Zimmerman, Jerome Grunat, Jeromy
French, Jeronimo, Jerry “DreadGazebo” LeNeave, Jerry Erica Nyssa Aeris Celes
Auric Romana, Jerry L. Meyr Jr., Jerry Sköld, Jesper Veje Walton Simonsen,
Jesse Burneko, Jesse Coombs, Jesse Kirkpatrick, Jesse Pudewell, Jessica
Hammer, Jet Cyngler, Jevon, Jim & Vicki Webster - \(Ryan's parents\), Jim
Dagg, Jim DelRosso, Jim McGarva, Jim Pacek, jim pinto, Jim Ryan, Jim South,
Jim Sweeney, Jimmy “JR” Ray Tyner 3rd, JMF Conklin, Joe, Joe Basham, Joe Howe,
Joe LaFerlita, Joe Pruitt, Joe Robertson, Joe Stroup, Joe Thater, Joe Thomas,
Joel, joel allan, Joey Rodgers, JoeyR, Johan Eriksson, Johannes, John
“Wildunknown” James, John Aegard, John Bogart, John Brown, John C. Schisler,
John Carroll, John Coates, John Colagioia, John Conklin, John D. Pankey, John
D. Wright, John Daniels, John Earley, John Eddy, John Fiala, John Gares Martin
III, John Harris, John Ivor Carlson, John Lammers, John Lantz, John LeBoeuf-
Little, John M. Campbell, John Marron, John Moran, John Perich, John Philip
Dennis Ryan, John Powell, John Stavropoulos, John Taber, John Thibodeau, John
Ward, John Wilson, Johnn Four, Johnnie Hafley, Johnny Bremer, Jon, Jon Cole,
Jon Leitheusser, Jon Sheppard, Jon Stump, Jon Stutzman, Jon Stutzman, Jon W.
Kroeger, Jonas Möckelström, Jonas Richter, Jonas Schiött, Jonatan Kilhamn,
Jonathan “Buddha” Davis, Jonathan Bristow, Jonathan Combs, Jonathan Ensor,
Jonathan Grimm, Jonathan Grosvenor, Jonathan Ingsley, Jonathan Jordan,
Jonathan Knapp, Jonathan Lavallee, Jonathan Lee, Jonathan Slack, Jonathan Sue,
Jonathan Tiong, Jonathan Westmoreland, Jordan “xRazoo” Jensen, Jordan Barber,
Jordan Bowman, Jordan Raymond, Jorge Prieto, Jose Garcia, Jose LaCario, Joseph
Ashley, Joseph Barnsley, Joseph Meyer, Joseph Murray Jr., Joseph Rossi, Josh
Chewning, Josh Drobina, Josh Foxford, Josh Gorfain, Josh Lynch, Josh Miller,
Josh Street, Joshua, Joshua Barney; “Qwitwa”, Joshua Card, Joshua Krutt,
Joshua Ramsey, Joshua Unruh, Joshua Wehner, José Luiz “Tzimiscedracul” F.
Cardoso, João Mariano, Juan “The Barbarian” Gonzalez, JUDD KARLMAN\! Julianna
Backer, June Owatari, Justin Achilli, Justin Barr, Justin Cranford, Justin D.
Jacobson, Justin Evans, Justin Hamilton, Justin Lance, Justin Melton, Justin S
Nafziger, Justin Smith, Justin Smith, Justin Stoddard, Justin Yeo, Justo R
Diaz, K. David Woolley, Kai Yau, Kamnev Mihail, Karl Jahn, Karl Miller, Karlen
“Sorcerer of the North” Kendrick, Karoline Dianne Keeney, Kas Anarky,
kasinoki, Kastor Lieberung, Kat Land, Kate Kirby, Kayne, Keilyn Lucent, Keith
Baker, Keith Blocker, Keith Carnes, Keith Gilmour, Dave Fountain and Doug
Hare, Keith M., Keith Preston, Keith Senkowski, Keith Stetson, Kelley Rogers,
kelly j v, Ken Arthur, Ken Harward, Ken St. Andre, Kendall Shields, Kenneth
Zeranski, kensboro, Kevin Denehy, Kevin Galloway, Kevin Heckman, Kevin
Lindgren, Kevin Lorson, Kevin M. James, Kevin Martin, Kevin Maynard, Kevin
McManus, Kevin Priest, Kevin Smith, Kevin Wallace, Kevin Wilson, Kevin Young,
Kien-Peng Lim, Kierya and Mordraeth, Kim Dong-Ryul, Kirby Young, Kirin
Robinson, Kjetil Kverndokken, Klaus Weidner, Kobayashi, Konstantinos
“Yo\!Master” Rentas, Kornel, Kristi Desinise, Kristian Cee, Kurt, Kurt
Dietrich, Kwyndig, Kyle Buehler, Kyle Burckhard, Kyle Payne, Kyle Rock, Kyle
Simons, Kyle Waldo Torres, Kyre, lacura17, Larry Lade, Lars Ericson, Lars
Larsen, Lars M. Nielsen, Lauren McMahon, Lavinia Fantini, LB Stouder, Lee
Engelhardt, Lee Garvin, Lee Sandow, Lee Short, Lee Zickel, Leif Erik Furmyr,
Leonard Balsera, Leonardo Facchin, Leroy Van Camp, Linda Larsson, Lior Wehrli,
Lisa 'The Mouse', Little Spartan Studios, Lizard, LogicNinja, Lond, High Mage
of Virtual Cartography, Lou Hayt, Louis Luangkesorn, Lovelydwarf, Luca Ricci,
Lucas Servideo, Lukas Myhan, Lukas Sjöström, Luke “Mournful” Jacobs, Luke
Bailey, Luke Walker, M. Bair, M. Sean Molley, M. Stevens Chase, M. W. II,
Maarten Bukkems, Madeline Ferwerda, MadRhetoric, Mads Egedal Kirchhoff, Mads
Marturin, maiki, Malcolm Harbrow, Malikor, Manohar Coussa, Manu Marron, Mar '
Iastra Yn D ' aan, Marc, Marc 'Szpil' A., Marc Hertogh, Marc Williamson, Marco
“Mr. Mac” Andreetto, Marco “Sagojo” Tripepi, Marco Bignami, Marco Brucale,
Marco Costantini, Marcos Silva, Marcus Bone, Marcus Burggraf, Marcus DLR,
Marijn Cornil, Marijn Hubert, Mariko Shewmake, Mark “Dojo” Brown, Mark
Bennett, Mark Best, Mark Couture, Mark Diaz Truman and Marissa Kelly, Magpie
Games, Mark Diffenderfer, Mark E Larson, Mark Featherston, Mark Harvey, Mark
Levad, Mark Maibroda, Mark Mealman, Mark Morrison, Mark Parker, Mark Shocklee,
Mark Solino, Mark Steen, Mark, Mary, Nathan & Hannah Watson, Markus Schoenlau,
Martijn Vos, Martin Costa, Lord High Phrenologist, Martin Griffin, Martin J.
Teply, Martin Ralya, Mathias Exner, Matias Frosterus, Matt, Matt & Nykki
Boersma, Matt and Katie Johnston, Matt Boeck, Matt Canale, Matt Clay, Matt
Donaldson, Matt Downer, Matt Herson, Matt Hogan, Matt Jackson, Matt Kimball,
Matt Landis, Matt Lewis, Matt Machell, Matt Maranda, Matt Mensch, Matt
Osborne, Matt Riley, Matt Sheridan, Matt Spain, Matt Strickling, Matt Weber,
Matt Wetherbee, Matt Widmann, Matt Wilson, Matteo Sasso, Matthew “Doc”
Michnik, Matthew Ashby, Matthew Blackwell, Matthew Broodie-Stewart, Matthew
Butler, Matthew Chan, Matthew D. Gandy, Matthew Diaz, Matthew Edwards, Matthew
Gomez, Matthew Graves, Matthew Haulman, Matthew Hughes, Matthew J. Hanson,
Matthew Keevil, Matthew Krykew, Matthew L. L. Wheeler, Matthew L. Seidl,
Matthew Lind, Matthew Miller, Matthew Nielsen, Matthew Parcell, Matthew
Patterson, Matthew Rees, Matthew Rolnick, Matthew Rooks, Matthew Uschelbec,
Matthew Ward, Matthew Wilde, Matthias 'darkpact' Nagy, mau, Maurice
“gilvanblight” Tousignant, Mauro Ghibaudo, Max “Ego” Hervieux, Max Villet,
Max.A, Maynard McGuffin, MB, mcsquiggedy, Md. Muazzam B. Sham Khiruddin, Meera
Barry, Mendel Schmiedekamp, Michael, Michael “rekenner” Renneker, Michael
'Minder' Riabov, Michael Atlin, Michael Barker, Michael Bentley, Michael
Bowman, Michael Cassimaty, Michael Cule, Michael Curry, Michael D Blanchard,
Michael D. Ranalli Jr., Michael De Rosa, Michael Fake, Michael Felgenhaur,
Michael Gunderson, Michael Harrel, Michael Harrison, Michael Hertling, Michael
Hill, Michael Hughes, Michael John, Michael Kailus, Michael Lewis, Michael
Llaneza, Michael Loy, Michael Marquez, Michael Miguel-Sanchez, Michael
Mitchell, Michael Nutt, Michael Nutter, Michael R. Underwood, Michael Rees,
Michael Richards, Michael Spinks, Michael St. Clair, Michael Stephenson,
Michael Swadling, Michael the OnlineDM, Michael W. Mattei, Michael Wasserman,
Michael Zautner, Michele “Mick” Toscan, Michelle “ChessyPig” Taylor, Michelle
Shepardson, Michelle, Connor and Xander, Miguel Zapico, Mikael Andersson,
Mikael Dahl, Mike & Keith MacArthur, Mike Addison, Mike D., Mike Davey, Mike
Dingeldein, Mike Edmonds, Mike Fitch, Mike Frazer, Mike G Jones, Mike Haggett,
Mike McMullan, Mike Miller, Mike Mudgett, Mike Olson, Mike Ramsey, Mike Reed,
Mike Riverso, Mike Sheley, Mike Simpson, Mike Welker, Mikko Kurki-Suonio,
Miles Gaborit, Miles Nerini, Milton M. Fernandez, Mircea Ungureanu, MO
Balbarin, Monica Speca, Monster Johnson, Monte, Mopsothoth, Morgan Ellis,
Morgan Gilbert, Morgan Hatfield, Morgan Hay, Morgan Westbrook, morgue, Moritz,
Morry Veer, Mr pLoLock, MrFatso from GBAtemp, Murph, Myles “The Funk Wagon”
McMann, Myles Corcoran, Myles McCloskey, N. Orlando Wilson, Nachiket A.
Patkar, Narayan Bajpe, Nat “woodelf” Barmore, Nat Webb, Nate Lawrence, Nate
Reed, Nathan Altice, Nathan Black, Nathan Frund, Nathan Kangas, Nathan Malynn,
Nathan Olmstead, Nathan Russell, Nathan Trail, Nathaniel W Jordan, Ned, Neil
A. Pinkerton, Neil Carr, Neil Goodridge, Neil Gow, Neil Knauth, Nels Anderson,
NerdBound Podcast, NextJenn Martin, Nic Webb, Nice Man, Nicholas Graziade,
Nicholas Hutchind, Nicholas Peterson, Nicholas Riley, Nick “Mystic5523”
Wesselmann, Nick “Necronomitron” Garcia, Nick Bate, Nick Brooke, Nick Buddell,
Nick Hrinda, Nick Pilon, Nick Townsend, Nick Warcholak, Nick wingedferret
Brown, Nicolas Acton, Nicolas G. Kruk, Nicole Trainor, Nicolás Brian,
Nightstorm, nikobe, Nikolai, Noah Hinz, Noble Kale, Noel Hoerst, Noggin,
Numinous, ObsidianBlk, OddHelge Gravalid, Odin, Oh Seung Han\(Wishsong\), Ola
Jostein Jørgensen, Olaf Kruse, Olav Nygård, Oliver Graf, Oliver Northrup,
Oliver Nøglebæk, Oliver von Spreckelsen, Olivier Brunet, Olivier Vigneresse,
Omer Golan-Joel, Orastes, Ovid, Ovlovian, Owen Kerr, Owen Meldrim Moore, Oxy
Morons, Pablo Iglesias Montañés, Pablo Palacios, Paolo “vonpaulus” Castelli,
Paolo “Koradji” Carnevali, Parke Hultman, Parker D Hicks, Pat “Silverhand”
Andrews, Pat Gamblin, Pat Kemp, Pat Sylves, Patrice Hédé, Patrice Mermoud,
Patricio Jones, Patrick “patmax17” Marchiodi, Patrick Clapp, Patrick Dawson,
Patrick Lee, Patrick Ley, Patrick Maguire, Patrick O'Brien, Patrick S Malone,
Patrick Sullivan, Paul, Paul “DQGM”, Paul Blair, Paul Casagrande, Paul
Cavanaugh, Paul DeMartino, Paul Edson, Paul Imboden, Paul Jenx, Paul
Mansfield, Paul R. Plaisance, Paul Smith, Paul Stefko, Paul Towler, Paul Vogt
- The Hopeless Gamer, Paul Watson, Paulo Segundo, Pedro Gómez-Esteban
González, Pedro Ziviani, Penny Greening, Perry Waterworth, Pete Falco, Pete
Figtree, Pete Griffith, Pete Hurley, Peter \*LifescanX' Poulsen, Peter Alvino,
Peter Aronson, Peter Bensley, Peter Borah, Peter Goderie, Peter Kristolaitis,
Peter Schichl, Peter Usagi, Peter Wessel Zapffe, Phil “DNAphil” Vecchione,
Phil Bordelon, Phil Burge, Phil Hobson, Phil Lewis, Phil Wong, Philip Reed,
Philippe Niederkorn, Phillip Bailey, Phillip Pierce-Savoie, Pierre-Philippe,
Piers, Piotr “Ifryt” Cichy, PJ, POUDEROUX Stephane, Preston Coutts, Psyestorm,
Pudge Dooley, Péterfy Áron, QED, Quentin “Q” Hudspeth, Quinn Conklin, R.
Zemlicka, R.R. Michael Humphreys, Rachel E.S. Walton, Rachel Luxemburg,
Rachelle Shelkey, Rafael Chandler, Rafael Guillen, Rafe Ball, Rafu, Rainer
Wagner-Ballner, Ralph Mazza, Randy Mosiondz, randy vranesh, Raphael
Grandsitzki, Ray Chiang, Reed Zesiger, Remi Treuer, Renato Ramonda, Renee
Knipe, Reno MWG Member Andy Barrett-Venn, Rev. Keith Johnson, Reverance
Pavane, Ricardo Tavares, Riccardo “Hammer” Nauti, Riccardo Broccoletti, Rich
Wheeler, Richard, Richard “Zelrokyz” Moss, Richard Almaraz, Richard Collins,
Richard Harrison, Richard Hirsch, Richard J Rogers, Richard Morton, Richard
Quick, Richard Sheppard, Richard T. Balsley, Rick Ferraro, Rick Harrelson,
Rick Rambo, Rikard Warvlin, Rob 'Wolfthulhu', Rob Alexander, Rob Brennan, Rob
Donoghue, Rob Gruhl, Rob McCarthy, Rob McDiarmid, Rob McNamee, Rob Sanderson
\(@azaroth42\), Rob Tillotson, Robert Adducci, Robert Carnel, Robert De Luna,
robert lambert, Robert MacNinch, Robert Mosley, Robert Slaughter, Robert
Summerill, Roberto Collingwood, Rod B. Spellman, Roderick Edwards, Roger N.
Dominick, Ron Blessing, Ron Merideth, Ross, Ross, Ross Cowman, Ross Hunter,
Ross Lemmon, Rowan Rose Lily Hazel Middleton, Roy from the RooSackGamers, RSC,
Rudy “Chainsaw” Basso, Rudy “Hikorzik” Rousseau, Rufo Sanchez, runester,
Rustin, Rusty Larner, Rustyn Sa, Ryan & Beth Perrin, Ryan Aech, Ryan Craig,
Ryan D. Chaddick, Ryan Dunleavy, Ryan Lee, Ryan Macklin, Ryan Moore, Ryan
Olson, Ryan S., Rémi Douence, S. Miles, S. Scapicchio, Sabe Jones, Sagi, Sam
“Nightrain” Carter, Sam Anderson, Sam Chupp, Sam Courtney, Sam Sowl, Sam
Zeitlin, Samuel Briggson, Samuel Crider, Samuel Kruse, Sara Williamson, Sarah
Harper, Sarn Aska, Sascha Lecours, Sawteeth, Scientivore, Scot Drew, Scott
“The Angry DM” Rehm, Scott Belchak, Scott Bennett, Scott Boehmer, Scott
Cunningham, Scott Dierdorf, Scott Gable, Scott Kemme, Scott Kinsey, Scott
Krok, Scott Madin, Scott McGougan, Scott Neilson, Scott R. Dierks, Scott
Rogers, Scott Sutherland, Scott Taylor, Scott Underwood, Scott W. Fail, Sean,
Sean Campbell, Sean Curtin, Sean Duncan, Sean Howard, Sean Lesley, Sean
Louvel, Sean P. Kelley, Sean P. Soderlind, Sean Pollman, Sean Silva-Miramon,
Sean Wills, Seanovan, Sebastian Haaf, Sebastian Hickey, Selene Tan, Sergio
Rodriguez, Seth & Rachael Blevins, Seth A. Roby, Seth Clayton, Seth Flagg,
Seth Johnson, Sethariel, sev, Seán Harnett, Shana Rosenfeld, Shane Donohoe,
Shane Kirby, Shane Majewski, Shane Mclean, Shane Williamson knew no
companions, Shannon Appelcline, Shannon Riddle, Shari Corey, Sharkbomb Game
Design Services, Shaun Hayworth, Shawn, Shawn Fagin, Shawn Quinn, Shawn
Tomkin, Shawn Tyler McCarthy, Shelton Windham \(taleswapper\), Shinversus,
Silvio Herrera Gea, Simon “Trooper94” Silva, Simon Crowe, Simon Gough, Simon
Paquette, Simon Sharp, Simon Weinert, Siobhan Morris, Sion Rodriguez y Gibson,
Sithilus, SJ Benoist, Soirgriffe, Sophia Lily Alsbrooks, Spencer, Stacey
Chancellor, Stefan, stefan tyler, Stefano R. Rebessi, Steffen Vulpius, Stephan
Szabo, Stephane Chopard, StephaNeil Wolfalter, Stephen Bretall, Stephen
Granade, Stephen Henderson-Grady, Stephen Holowczyk, Stephen Parkin, Stephen
Smoak, Stephen Wilcoxon, Sterling, Stern Krueger, Steve Benton, Steve
Bergeron, Steve Bode, Steve Dodge, Steve Hickey, Steve Holder, Steve Kenson,
Steve Knowlton, Steve Mains, Steve Moore, Steven Barker, Steven D Warble,
Steven Damer, Steven Grady, Steven Holst-Diemand, Steven Jarvis, Steven K.
Watkins, Steven Martindale, Steven Robert, Steven Scibetta, Steven Vest,
StingRay, Stuart Chaplin, Stuart McDermid, Sven Folkesson, Sven Hannemann,
Sven Stryker, Sławomir Wrzesień, T.S. Luikart, T.W.Wombat, Tablesaw, Tadeusz
Cantwell, TAK, Tanya Cohan-Diaz, Tapani Tiilikainen, Tas Stacey, tavernbman,
Ted Cabeen, Ted Novy, Ted Williams, teeter, Tellef, Thail, That One Die That
Never Lets You Down, The Campbells, The Daughters of Verona, The Great and
Mighty Neb, The guys at Fort Nerd, The High Lord Mhoram, of the Dark Ones,
Master of the Black Citadel, Doctrina Magicus, The Infamous P.I.G., The Lord
of Lime Sherbert, The Magus\!\!1\!, the memory of Ada Lovelace, The Memory of
Dave Arneson, The Nashv​ille Irreg​ulars, The Secret DM, The Sutra of Supreme
Excellence, TheCatfish, Theron Teter, Thibault Mesmin d'Estienne, Thomas Foss
Christensen, Thomas Ryan, Thomas Ulricht, Thorbjørn Steen, ThorDiantral,
Thriondel Half-Elven, Tiago Marinho, Tim “Buzz” Isakson, Tim Ballew, Tim
Hutchings, Tim Knight, Tim McCracken, Timothy Sanders, TJBailey, Todd
Mitchell, Todd Roy, Todd Zircher, Tolly, Tom Cadorette, Tom Flanagan, Tom
Idleman, Tom Ladegard, Tom Lumley, Tom McCarthy, Tom Reynolds, Tomasz Pudło,
Tomek Filip, Tony, Tony, Tony Dijkstra, Tony Eng, Tony Indurante, Tony Love,
Tony Reyes, Topi Makkonen, Torolf, Trachalio, Tracy Barnett/Sand & Steam
Productions, Tracy Hurley, Travis Bryant, Travis Scott, Trent Casey, Trent
Yacuk, Trevis Martin, Trey Mercer, Trollhawke, Troy “Wrongtown” Hall, Troy
Gilbert, Troy M. Costisick, Tuomas, Turk, txelu, Ty Sawyer, Tyler Jones, Tyler
Lanser, Uffe Thorsen, Ulysses, Umberto Pignatelli, Unisprink, Vacuumjockey,
Vera Vartanian, Vernon Lingley, Veronica Courage Wakefield, Victor Lane,
Victor Maslov, Victor Wyatt, Victoria Uney, Viktor Haag, Ville Halonen,
Vinicius Lessa, Vites, Vlad Del Cid, Vladimir Dzundza, Vladimir Filipović, W.
Scott Jones, Wade “Belzain” Ussery, Walt Robillard, Warrbo, Warren “Mook”
Wilson, Warren Merrifield, Wayne “Lumrunner” Humfleet, Wayne Arthurton, Wayne
Lauer, Wei-Hua, Hsieh, Wes Price, Weston Clowney, White Paws, Whitt, Wilhelm
Fitzpatrick, Will Ijebor, Will Robot, Will Thibault, Will Vesely, William
“CallMeWilliam” Nichols, William Ansell, William Carroll, William Fischer,
William Gerke, William K Wood, William Koch, Willis Scilacci, Wing Chan, WJO
III, Wojciech Gębczyk, Wolfberry, WOoDY, Wothbora, wraith808, Wyatt Camp,
Xander Veerhoff, Xavier Aubuchon-Mendoza, Xellos, cleric of coins, xiangh, Yan
Prado, Yoki Erdtman, Yragael, Z. Dettwyler, Zach Clay, Zach Gourley, Zach
Peters, Zachary Hall, Zachary Sylvain, Zachary Williams, Zack Kline, Zack
Woodard, Zane Ewers, zero.executioner, Zippy Schindler, Zontco Gaming
Division, ZSP, östen petersson.

